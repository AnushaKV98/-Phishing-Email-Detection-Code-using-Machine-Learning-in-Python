from pathlib import Path
import joblib
import sys

MODEL = Path(__file__).resolve().parent / "models" / "phishing_email_model.joblib"
if not MODEL.exists():
    raise SystemExit("Model not found. Run: python train_model.py")
model = joblib.load(MODEL)

text = " ".join(sys.argv[1:]).strip()
if not text:
    text = input("Paste the email text: ").strip()
if not text:
    raise SystemExit("No email text supplied.")

prediction = model.predict([text])[0]
probabilities = model.predict_proba([text])[0]
classes = list(model.classes_)
phishing_probability = probabilities[classes.index("phishing")]

print(f"Prediction: {prediction.upper()}")
print(f"Estimated phishing probability: {phishing_probability:.1%}")
print("Note: This is a machine-learning estimate, not a guarantee of safety.")
