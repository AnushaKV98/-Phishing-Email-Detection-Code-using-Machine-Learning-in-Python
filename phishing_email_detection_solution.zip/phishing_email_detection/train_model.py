from pathlib import Path
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix

BASE = Path(__file__).resolve().parent
DATA = BASE / "data" / "emails.csv"
MODEL_DIR = BASE / "models"
MODEL_DIR.mkdir(exist_ok=True)

df = pd.read_csv(DATA).dropna(subset=["text", "label"])
df["label"] = df["label"].str.strip().str.lower()
df = df[df["label"].isin(["phishing", "legitimate"])]
if df["label"].nunique() < 2:
    raise SystemExit("Dataset must contain both phishing and legitimate labels.")

X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["label"], test_size=0.25, random_state=42, stratify=df["label"]
)
model = Pipeline([
    ("tfidf", TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=5000)),
    ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
])
model.fit(X_train, y_train)
pred = model.predict(X_test)

print(f"Accuracy: {accuracy_score(y_test, pred):.3f}")
print("Confusion matrix (labels: legitimate, phishing):")
print(confusion_matrix(y_test, pred, labels=["legitimate", "phishing"]))
print(classification_report(y_test, pred, zero_division=0))
joblib.dump(model, MODEL_DIR / "phishing_email_model.joblib")
print(f"Model saved to: {MODEL_DIR / 'phishing_email_model.joblib'}")
