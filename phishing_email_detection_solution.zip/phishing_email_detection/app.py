from pathlib import Path
import joblib
import streamlit as st

MODEL = Path(__file__).resolve().parent / "models" / "phishing_email_model.joblib"
st.set_page_config(page_title="Phishing Email Detector", page_icon="🛡️")
st.title("Phishing Email Detection")
st.write("Paste an email message to estimate whether it is phishing or legitimate.")

if not MODEL.exists():
    st.warning("The model has not been trained yet. Run `python train_model.py` first.")
    st.stop()

model = joblib.load(MODEL)
email_text = st.text_area("Email content", height=220, placeholder="Paste the email subject and body here...")
if st.button("Analyze email", type="primary"):
    if not email_text.strip():
        st.error("Please enter an email message.")
    else:
        prediction = model.predict([email_text])[0]
        probs = model.predict_proba([email_text])[0]
        phishing_prob = float(probs[list(model.classes_).index("phishing")])
        if prediction == "phishing":
            st.error("Likely phishing email")
        else:
            st.success("Likely legitimate email")
        st.metric("Estimated phishing probability", f"{phishing_prob:.1%}")
        st.caption("This educational prototype analyzes text patterns only. It does not verify sender identity, visit URLs, scan attachments, or guarantee that an email is safe.")
