# Phishing Email Detection using Machine Learning (Python)

A small educational project that classifies email text as **phishing** or **legitimate** using TF-IDF text features and Logistic Regression.

## Project contents

- `data/emails.csv` — small illustrative dataset included so the project runs immediately.
- `train_model.py` — cleans the CSV, trains the model, prints evaluation metrics, and saves the model.
- `predict.py` — predicts from a command-line email message.
- `app.py` — optional Streamlit web interface.
- `models/` — trained model is created here after training.

## Requirements

Python 3.9 or later is recommended.

## Run on Windows

Open Command Prompt in this project folder and run:

```bash
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python train_model.py
```

Try a prediction:

```bash
python predict.py "Your account will be suspended. Click this link to verify your password immediately."
```

Run the web interface:

```bash
streamlit run app.py
```

## Use a larger dataset

The included CSV is deliberately small and illustrative; its metrics are not suitable for research claims or real-world deployment. For meaningful evaluation, replace `data/emails.csv` with a properly licensed, representative dataset containing these columns:

- `text`: email subject/body text
- `label`: `phishing` or `legitimate`

Keep examples from the same campaign or near-duplicates together when splitting data to reduce data leakage. Evaluate on a separate, representative test set before drawing conclusions.

## How it works

1. Reads and validates labelled email text.
2. Converts words and word pairs into TF-IDF features.
3. Trains a Logistic Regression classifier.
4. Reports accuracy, precision, recall, F1-score, and a confusion matrix.
5. Saves the fitted pipeline for later predictions.

## Important limitations

This is a classroom demonstration, not production email security software. The small included dataset is synthetic/illustrative and will not generalize reliably. Text-only classification cannot authenticate the sender, inspect headers or attachments, safely resolve URLs, or guarantee that an email is safe. A legitimate email may be flagged, and a phishing email may be missed. Do not open suspicious links or attachments based on this tool's output.

## Reference video

The project topic was requested with this video: https://www.youtube.com/watch?v=5qica9DYTGY
